/*
Written by Austin Newton
01/27/2021
 */
package minilabsyntax;

public class MiniLabSyntax {

  
    public static void main(String[] args) {
        
        // Declaring variables about myself and assigning values
        
        String myName = "Austin Newton";
        int myAge = 24;
        String myGender = "M";
        float myGPA = 4.0f;
        String myExp = "I have programmed before.";
        
        // Printing the values to the screen
        
        System.out.println("My name is " + myName + ".");
        System.out.println("I am currently " + myAge + " years old.");
        System.out.println("My gender is " + myGender + ".");
        System.out.println("I have a GPA of " + myGPA + ".");
        System.out.println(myExp);
        
        // Printing my name in block letters
        
        /* The print function is extremely hard to read.
           I was unable to find another way to get the output expected. 
           I have left other methods I had tried before settling on the one used. 
        */
       
        
        System.out.print("  A \t U   U \t SSSS \t TTTTT \t I\t N N     N\nA   A \t U   U \t S \t   T \t I \t N  N    N\nAAAAA \t U   U \t S \t   T \t I \t N   N   N\nA   A\t U   U \t    S \t   T \t I \t N    N  N\nA   A\t U   U\t    S \t   T \t I \t N     N N\nA   A\t UUUUU \t SSSS \t   T \t I \t N      NN");
        
        
        
        
        //System.out.print("  A \nA   A \nAAAAA\nA   A\nA   A\nA   A \t U");
        //String letterA = "  A \nA   A \nAAAAA\nA   A\nA   A\nA   A";
        //String letterU = "\t";
        //System.out.print(letterA);
        //System.out.print(letterU);
        
        
        
        
        
    }
    
}
