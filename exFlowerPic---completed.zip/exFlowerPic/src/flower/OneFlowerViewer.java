package flower;//	.	........

public class OneFlowerViewer
{
   public static void main(String[] args)
   {
       Flower rose = new Flower(30, 30);
       rose.draw();
   }
}
