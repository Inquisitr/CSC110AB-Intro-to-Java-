package flower;//	.	........

public class FlowerViewer
{
   public static void main(String[] args)
   {
       Flower rose = new Flower(30, 30);
       rose.draw();
       
       rose = new Flower(80, 60);
       rose.draw();
   }
}
