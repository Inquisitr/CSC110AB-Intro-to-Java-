/*     File: Circle.java//	.	........
 *     Name: ***************, Course CSC110 TIME
 *     Date: MM/DD/YYYY
 *  Purpose: Learn to create a class
 */
package circleclass;

//import graphics

public class Circle 
{
    //Data
    
    //Constructors
    public Circle() //default Circle constructor: 30, 30, 20, BLUE
    {

    }

    //Constructor with x, y, diameter
    //public Circle(x, y, d)

    
    //Accessors for x, y, diameter, color
    //TODO: Finish getDiameter() & getColor()
    
    //Mutators for x, y, diameter, color
    //TODO: Finish setColor()

    //Methods
    public double area()
    {
        //TODO: Finish area()
        return 0.0;
    }
    
    //Draw this circle, filled with current color
    public void draw()
    {

    }

    //String for this circle: "Circle: x=##.#, y=##.#, d=##.#, color=(R,G,B)"
    public String toString()
    {
        String msg;
        msg  = "Circle: ";

        return  msg; 
    }
}
